#!/bin/bash
echo " " > ../FORMELN/f1.me
./pTest ../FORMELN/f1 >> ../FORMELN/f1.me
echo " " > ../FORMELN/f2.me
./pTest ../FORMELN/f2 >> ../FORMELN/f2.me
echo " " > ../FORMELN/f3.me
./pTest ../FORMELN/f3>> ../FORMELN/f3.me
